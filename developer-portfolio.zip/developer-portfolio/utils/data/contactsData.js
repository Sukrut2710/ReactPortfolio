export const contactsData = {
    email: 'sukrutdani@gmail.com',
    phone: '+1 (709) 693-6634',
    address: 'St. Johns, NL, Canada',
    sheetAPI: '',
    github: 'https://github.com/Sukrut2710',
    facebook: 'https://www.facebook.com/sukrut.dani/',
    linkedIn: 'https://www.linkedin.com/in/sukrut-dani/',
    instagram: 'https://www.instagram.com/sukrutdani/',
    youtube: 'https://www.youtube.com/c/sukrutdanivlogs',
    resume: "https://drive.google.com/file/d/1lb4QvCrVM0cP2LRBOCSdhp-qYGTrfOZZ/view?usp=drive_link"
}