export const experiences = [
  {
    id: 1,
    title: 'Web Developer',
    company: "SouthPark Driving School",
    duration: "(Feb 2023 - Present)"
  },
  {
    id: 2,
    title: "Teaching Assistant",
    company: "Memorial University of Newfoundland",
    duration: "(Jan 2023 - Dec 2023)"
  },
  {
    id: 3,
    title: "Software Developer Analyst",
    company: "Accenture India",
    duration: "(Jan 2020 - July 2022)"
  }
]