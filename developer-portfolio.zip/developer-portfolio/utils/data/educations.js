export const educations = [
  {
    id: 1,
    title: "Master of Science - Computer Science",
    duration: "2022 - 2024",
    institution: "Memorial University of Newfoundland",
    GPA: "3.6"
  },
  {
    id: 2,
    title: "Bachelor of Engineering - Information Technology",
    duration: "2015 - 2019",
    institution: "Pune University",
    GPA: "3.8"
  }
]